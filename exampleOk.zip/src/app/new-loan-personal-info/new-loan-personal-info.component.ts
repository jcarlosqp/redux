import { Component, OnInit, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import * as fromPersonal from '../state/personal/personal.reducer';
import { Store } from '@ngrx/store';
import { Personal } from '../models/personal';
import * as actions from './../state/personal/personal.actions';

@Component({
  selector: 'new-loan-personal-info',
  templateUrl: './new-loan-personal-info.component.html',
  styleUrls: ['./new-loan-personal-info.component.scss']
})
export class NewLoanPersonalInfoComponent implements OnInit {
  @Input() formGroupPersonalInfo:FormGroup;
  personal: Personal;

  constructor(private store: Store<fromPersonal.State>) { 
    this.store
			.select(fromPersonal.getPersonalInfo)
			.subscribe(info => {
        this.personal = info;
        console.log('get personal:', this.personal);
			});
  }

  ngOnInit() {
    this.Load();
  }

  Load() {
		this.store.dispatch(new actions.Load());
	}
}
