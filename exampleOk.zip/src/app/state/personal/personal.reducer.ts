
import { Personal } from 'src/app/models/personal';
import { PersonalActions, PersonalActionTypes } from './personal.actions';

export interface State {
    personalInfo: Personal;
    isLoading: boolean;
}

const initialState: State = {
    personalInfo: new Personal('-', '-','0','-'),
    isLoading: false
};

export function personalReducer(state: State = initialState, action: PersonalActions): State {
	switch (action.type) {
        case PersonalActionTypes.Load:
			return {
				...state,
                isLoading: true
            };
        case PersonalActionTypes.LoadComplete:
			return {
                ...state,
                personalInfo: action.payload,
                isLoading: false
			};
		case PersonalActionTypes.Apply:
			return {
				...state,
                personalInfo: action.payload,
                isLoading: false
			};
		default:
			return state;
	}
}

export const getPersonalInfo = (state: State) => state.personalInfo;
export const getIsLoading = (state: State) => state.isLoading;