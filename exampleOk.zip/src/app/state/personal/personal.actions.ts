import { Action } from '@ngrx/store';
import { Personal } from 'src/app/models/personal';

export enum PersonalActionTypes {
    Load = '[Personal] Load',
    LoadComplete = '[Personal] LoadComplete',
	Apply = '[Personal] Apply',
}

export class Load implements Action {
	readonly type = PersonalActionTypes.Load;
	constructor() {}
}
export class LoadComplete implements Action {
	readonly type = PersonalActionTypes.LoadComplete;
	constructor(public payload: Personal) {}
}
export class Apply implements Action {
	readonly type = PersonalActionTypes.Apply;
	constructor(public payload: Personal) {}
}
export type PersonalActions = Load | LoadComplete | Apply;