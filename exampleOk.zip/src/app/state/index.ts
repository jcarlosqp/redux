import { ActionReducer, ActionReducerMap, createFeatureSelector, createSelector, MetaReducer } from '@ngrx/store';
import { environment } from '../../environments/environment';
import * as fromPersonal from '../state/personal/personal.reducer';

export interface State {
	personal: fromPersonal.State;
}
export const reducers: ActionReducerMap<State> = {
	personal: fromPersonal.personalReducer
};
export const getPersonalState = createFeatureSelector<fromPersonal.State>('personal');
export const getPersonalInfo = createSelector(getPersonalState, fromPersonal.getPersonalInfo);
// Log actions in development mode
export function logger(reducer: ActionReducer<State>): ActionReducer<State> {
	return function(state: State, action: any): State {
		console.log('state', state);
		console.log('action', action);
		return reducer(state, action);
	};
}

export const metaReducers: MetaReducer<State>[] = !environment.production ? [logger] : [];