export class Personal {
    constructor( public firstName: string, public lastName: string, public dni: string, public address: string) {}
}